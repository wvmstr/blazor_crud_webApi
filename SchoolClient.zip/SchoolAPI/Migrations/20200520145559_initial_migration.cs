﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace SchoolAPI.Migrations
{
    public partial class initial_migration : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Students",
                columns: table => new
                {
                    StudentId = table.Column<string>(nullable: false),
                    FirstName = table.Column<string>(nullable: false),
                    LastName = table.Column<string>(nullable: false),
                    School = table.Column<string>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Students", x => x.StudentId);
                });

            migrationBuilder.InsertData(
                table: "Students",
                columns: new[] { "StudentId", "FirstName", "LastName", "School" },
                values: new object[,]
                {
                    { "946bfb8c-1f96-49ea-afcf-a30ba3378af9", "Jane", "Smith", "Medicine" },
                    { "1f9c5bd1-2df9-4775-854f-260f220dc127", "John", "Fisher", "Engineering" },
                    { "262af9b5-c84a-4bb7-ab9b-5ac59dd05b6b", "Pamela", "Baker", "Food Science" },
                    { "61dd6b0d-57f2-446c-99c5-66f85ae3ed0f", "Peter", "Taylor", "Mining" }
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Students");
        }
    }
}
